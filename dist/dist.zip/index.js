const CLIENT_ID = 'lUfL6jTbcalTAbA8QXE_6cJAyN7kT9AVaITmff86e54';
let ACCESS_TOKEN = '';

function getSite() {

}

function init() {
	let hash = location.hash || '';
	if (hash.length === 0) {
		const state = Math.random();
		const redirectURI = location.protocol + '//' + location.host;
		const url = 'https://app.netlify.com/authorize?' +
			'client_id=' + CLIENT_ID +
			'&response_type=token' +
			'&redirect_uri=' + redirectURI +
			'&state=' + state;
		location.href = url;
	} else {
		console.log('HASH = ', hash);
		if (hash.startsWith('#access_token=')){
			hash = hash.substr('#access_token='.length);
			
		}
	}
}

window.onload = init;
